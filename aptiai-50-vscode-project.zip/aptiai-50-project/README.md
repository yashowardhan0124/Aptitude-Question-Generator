# AptiAI 50+ — Aptitude Assessment & Dataset Engine

## How to Run in VS Code
1. Extract this ZIP folder and open it in **VS Code** (`File -> Open Folder`).
2. Open the integrated terminal (`Ctrl + ~` or `Terminal -> New Terminal`).
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the local development server:
   ```bash
   npm run dev
   ```
5. Open the URL shown in the terminal (usually `http://localhost:5173`).

## Project Structure
- `src/types/aptitude.ts` — TypeScript interfaces for questions, quizzes, and results.
- `src/data/builtinDataset.ts` — Complete 56-question dataset across 6 domains.
- `src/components/Navbar.tsx` — Sticky navigation bar & dark/light theme toggle.
- `src/components/DashboardView.tsx` — Analytics banner, metrics cards, recent attempts, and bookmarks.
- `src/components/GeneratorView.tsx` — Quiz configurator (mode, domain, difficulty, count, timer).
- `src/components/QuizPlayerView.tsx` — Live quiz interface, instant feedback, and formula hint modal.
- `src/components/ResultsView.tsx` — Performance scorecard & step-by-step solution breakdown.
- `src/components/QuestionBankView.tsx` — Searchable explorer, JSON import/export, and custom question modal.
- `src/App.tsx` — Main application state and view router.
