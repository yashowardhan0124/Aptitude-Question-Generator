import React, { useState, useEffect, useMemo } from 'react';
import { BUILTIN_DATASET } from './data/builtinDataset';
import { Question, QuizSession, CompletedResult } from './types/aptitude';
import { Navbar } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { GeneratorView } from './components/GeneratorView';
import { QuizPlayerView } from './components/QuizPlayerView';
import { ResultsView } from './components/ResultsView';
import { QuestionBankView } from './components/QuestionBankView';

export default function App() {
  const [currentView, setCurrentView] = useState('generator');
  const [darkMode, setDarkMode] = useState(true);

  // Dataset State with LocalStorage
  const [dataset, setDataset] = useState<Question[]>(() => {
    const saved = localStorage.getItem('apti_ai_dataset_v3');
    return saved ? JSON.parse(saved) : BUILTIN_DATASET;
  });

  // Bookmarks State
  const [bookmarks, setBookmarks] = useState<string[]>(() => {
    const saved = localStorage.getItem('apti_ai_bookmarks_v3');
    return saved ? JSON.parse(saved) : [];
  });

  // Quiz Generator Settings
  const [genCategory, setGenCategory] = useState('All Categories');
  const [genDifficulty, setGenDifficulty] = useState('All');
  const [genCount, setGenCount] = useState(10);
  const [genTimeLimit, setGenTimeLimit] = useState(10);
  const [quizMode, setQuizMode] = useState('test');
  const [isGenerating, setIsGenerating] = useState(false);

  // Active Quiz State
  const [activeQuiz, setActiveQuiz] = useState<QuizSession | null>(null);
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [hintModalOpen, setHintModalOpen] = useState(false);

  // Quiz History State
  const [quizHistory, setQuizHistory] = useState<CompletedResult[]>(() => {
    const saved = localStorage.getItem('apti_ai_history_v3');
    return saved ? JSON.parse(saved) : [];
  });

  // Last Results State
  const [lastResults, setLastResults] = useState<CompletedResult | null>(null);

  // Practice Explorer Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [practiceCat, setPracticeCat] = useState('All');
  const [practiceDiff, setPracticeDiff] = useState('All');

  // Custom Question Modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [newQ, setNewQ] = useState({
    category: 'Quantitative Aptitude',
    subCategory: 'General',
    difficulty: 'Medium',
    question: '',
    options: ['', '', '', ''],
    correctIndex: 0,
    explanation: '',
    formula: '',
  });

  // Save changes to localStorage
  useEffect(() => {
    localStorage.setItem('apti_ai_dataset_v3', JSON.stringify(dataset));
  }, [dataset]);

  useEffect(() => {
    localStorage.setItem('apti_ai_bookmarks_v3', JSON.stringify(bookmarks));
  }, [bookmarks]);

  useEffect(() => {
    localStorage.setItem('apti_ai_history_v3', JSON.stringify(quizHistory));
  }, [quizHistory]);

  // Quiz Timer Engine
  useEffect(() => {
    let timer: ReturnType<typeof setInterval>;
    if (activeQuiz && !activeQuiz.isFinished && activeQuiz.mode === 'test') {
      timer = setInterval(() => {
        setActiveQuiz((prev) => {
          if (!prev) return null;
          const newElapsed = prev.timeElapsed + 1;
          if (prev.timeLimit > 0 && newElapsed >= prev.timeLimit * 60) {
            finishQuiz({ ...prev, timeElapsed: newElapsed });
            return null;
          }
          return { ...prev, timeElapsed: newElapsed };
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [activeQuiz]);

  // Unique Categories
  const categories = useMemo(() => {
    const cats = new Set(dataset.map((item) => item.category));
    return ['All Categories', ...Array.from(cats)];
  }, [dataset]);

  // Toggle Bookmark
  const toggleBookmark = (qId: string) => {
    setBookmarks((prev) =>
      prev.includes(qId) ? prev.filter((id) => id !== qId) : [...prev, qId]
    );
  };

  // Launch Quiz
  const handleStartQuiz = () => {
    setIsGenerating(true);
    setTimeout(() => {
      let pool = [...dataset];
      if (genCategory !== 'All Categories') {
        pool = pool.filter((q) => q.category === genCategory);
      }
      if (genDifficulty !== 'All') {
        pool = pool.filter((q) => q.difficulty === genDifficulty);
      }

      const shuffled = [...pool].sort(() => 0.5 - Math.random());
      const selected = shuffled.slice(0, Math.min(genCount, shuffled.length));

      if (selected.length === 0) {
        alert("No questions matched your selection criteria. Try choosing 'All Categories'.");
        setIsGenerating(false);
        return;
      }

      const quizData: QuizSession = {
        id: Date.now(),
        date: new Date().toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
          year: 'numeric',
        }),
        questions: selected,
        userAnswers: new Array(selected.length).fill(null),
        timeLimit: Number(genTimeLimit),
        timeElapsed: 0,
        mode: quizMode,
        isFinished: false,
      };

      setActiveQuiz(quizData);
      setCurrentQIndex(0);
      setIsGenerating(false);
      setCurrentView('quiz');
    }, 400);
  };

  // Select Option
  const handleSelectOption = (optIndex: number) => {
    if (!activeQuiz) return;
    const newAnswers = [...activeQuiz.userAnswers];
    newAnswers[currentQIndex] = optIndex;
    setActiveQuiz({ ...activeQuiz, userAnswers: newAnswers });
  };

  // Submit & Finish Quiz
  const finishQuiz = (quizToFinish: QuizSession | null = activeQuiz) => {
    if (!quizToFinish) return;

    let score = 0;
    const categoryStats: Record<string, { total: number; correct: number }> = {};

    quizToFinish.questions.forEach((q, idx) => {
      const isCorrect = quizToFinish.userAnswers[idx] === q.correctIndex;
      if (isCorrect) score++;

      if (!categoryStats[q.category]) {
        categoryStats[q.category] = { total: 0, correct: 0 };
      }
      categoryStats[q.category].total += 1;
      if (isCorrect) categoryStats[q.category].correct += 1;
    });

    const percent = Math.round((score / quizToFinish.questions.length) * 100);

    const completedResult: CompletedResult = {
      ...quizToFinish,
      score,
      total: quizToFinish.questions.length,
      percentage: percent,
      categoryStats,
      finishedAt: new Date().toISOString(),
    };

    setQuizHistory((prev) => [completedResult, ...prev]);
    setLastResults(completedResult);
    setActiveQuiz(null);
    setCurrentView('results');
  };

  // JSON Dataset Export
  const handleExportJSON = () => {
    const dataStr =
      'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(dataset, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `apti_dataset_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // JSON Dataset Import
  const handleImportJSON = (event: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    if (event.target.files && event.target.files[0]) {
      fileReader.readAsText(event.target.files[0], 'UTF-8');
      fileReader.onload = (e) => {
        try {
          const parsed = JSON.parse(e.target?.result as string);
          if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].question) {
            setDataset(parsed);
            alert(`Successfully loaded ${parsed.length} questions into the dataset!`);
          } else {
            alert('Invalid JSON format. Make sure it is an array of valid question objects.');
          }
        } catch (err) {
          alert('Error parsing JSON file. Please check syntax.');
        }
      };
    }
  };

  // Add Custom Question
  const handleAddQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQ.question || newQ.options.some((o) => !o.trim())) {
      alert('Please complete the question prompt and all 4 choices.');
      return;
    }
    const created: Question = {
      ...newQ,
      id: `custom_${Date.now()}`,
    };
    setDataset([created, ...dataset]);
    setShowAddModal(false);
    setNewQ({
      category: 'Quantitative Aptitude',
      subCategory: 'General',
      difficulty: 'Medium',
      question: '',
      options: ['', '', '', ''],
      correctIndex: 0,
      explanation: '',
      formula: '',
    });
  };

  // Filtered dataset for Practice Explorer
  const filteredDataset = useMemo(() => {
    return dataset.filter((q) => {
      const matchCat = practiceCat === 'All' || q.category === practiceCat;
      const matchDiff = practiceDiff === 'All' || q.difficulty === practiceDiff;
      const matchSearch =
        q.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
        q.subCategory.toLowerCase().includes(searchQuery.toLowerCase());
      return matchCat && matchDiff && matchSearch;
    });
  }, [dataset, practiceCat, practiceDiff, searchQuery]);

  // Summary Metrics
  const overallStats = useMemo(() => {
    const totalTaken = quizHistory.length;
    if (totalTaken === 0)
      return { totalTaken: 0, avgScore: 0, bestScore: 0, questionsAnswered: 0 };

    let sumAcc = 0;
    let maxAcc = 0;
    let totalQ = 0;

    quizHistory.forEach((h) => {
      sumAcc += h.percentage;
      if (h.percentage > maxAcc) maxAcc = h.percentage;
      totalQ += h.questions.length;
    });

    return {
      totalTaken,
      avgScore: Math.round(sumAcc / totalTaken),
      bestScore: maxAcc,
      questionsAnswered: totalQ,
    };
  }, [quizHistory]);

  return (
    <div
      className={`min-h-screen font-sans antialiased transition-colors duration-300 ${
        darkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'
      }`}
    >
      {/* GLOWING AMBIENT BACKGROUND ORBS */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0 opacity-40">
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-indigo-600 rounded-full blur-3xl opacity-30 animate-pulse"></div>
        <div className="absolute top-1/2 -right-40 w-96 h-96 bg-purple-600 rounded-full blur-3xl opacity-30"></div>
        <div className="absolute -bottom-40 left-1/3 w-96 h-96 bg-cyan-600 rounded-full blur-3xl opacity-20"></div>
      </div>

      {/* HEADER NAVBAR */}
      <Navbar
        currentView={currentView}
        setCurrentView={setCurrentView}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
      />

      {/* MAIN CONTENT AREA */}
      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {currentView === 'dashboard' && (
          <DashboardView
            darkMode={darkMode}
            dataset={dataset}
            bookmarks={bookmarks}
            toggleBookmark={toggleBookmark}
            quizHistory={quizHistory}
            overallStats={overallStats}
            setCurrentView={setCurrentView}
            setLastResults={setLastResults}
          />
        )}

        {currentView === 'generator' && (
          <GeneratorView
            darkMode={darkMode}
            categories={categories}
            quizMode={quizMode}
            setQuizMode={setQuizMode}
            genCategory={genCategory}
            setGenCategory={setGenCategory}
            genDifficulty={genDifficulty}
            setGenDifficulty={setGenDifficulty}
            genCount={genCount}
            setGenCount={setGenCount}
            genTimeLimit={genTimeLimit}
            setGenTimeLimit={setGenTimeLimit}
            isGenerating={isGenerating}
            handleStartQuiz={handleStartQuiz}
          />
        )}

        {currentView === 'quiz' && activeQuiz && (
          <QuizPlayerView
            darkMode={darkMode}
            activeQuiz={activeQuiz}
            currentQIndex={currentQIndex}
            setCurrentQIndex={setCurrentQIndex}
            bookmarks={bookmarks}
            toggleBookmark={toggleBookmark}
            handleSelectOption={handleSelectOption}
            finishQuiz={() => finishQuiz()}
            hintModalOpen={hintModalOpen}
            setHintModalOpen={setHintModalOpen}
          />
        )}

        {currentView === 'results' && lastResults && (
          <ResultsView
            darkMode={darkMode}
            lastResults={lastResults}
            setCurrentView={setCurrentView}
          />
        )}

        {currentView === 'practice' && (
          <QuestionBankView
            darkMode={darkMode}
            filteredDataset={filteredDataset}
            categories={categories}
            bookmarks={bookmarks}
            toggleBookmark={toggleBookmark}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            practiceCat={practiceCat}
            setPracticeCat={setPracticeCat}
            practiceDiff={practiceDiff}
            setPracticeDiff={setPracticeDiff}
            handleExportJSON={handleExportJSON}
            handleImportJSON={handleImportJSON}
            showAddModal={showAddModal}
            setShowAddModal={setShowAddModal}
            newQ={newQ}
            setNewQ={setNewQ}
            handleAddQuestion={handleAddQuestion}
          />
        )}
      </main>
    </div>
  );
}
