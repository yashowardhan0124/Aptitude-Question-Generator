import React from 'react';
import {
  Brain,
  CheckCircle2,
  Clock,
  BookOpen,
  Bookmark,
  BookmarkCheck,
  Play,
  Target,
  Flame,
  ChevronRight,
  Award,
} from 'lucide-react';
import { Question, CompletedResult } from '../types/aptitude';

interface DashboardViewProps {
  darkMode: boolean;
  dataset: Question[];
  bookmarks: string[];
  toggleBookmark: (id: string) => void;
  quizHistory: CompletedResult[];
  overallStats: {
    totalTaken: number;
    avgScore: number;
    bestScore: number;
    questionsAnswered: number;
  };
  setCurrentView: (view: string) => void;
  setLastResults: (res: CompletedResult) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  darkMode,
  dataset,
  bookmarks,
  toggleBookmark,
  quizHistory,
  overallStats,
  setCurrentView,
  setLastResults,
}) => {
  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Banner */}
      <div
        className={`p-8 rounded-3xl border backdrop-blur-xl relative overflow-hidden ${
          darkMode
            ? 'bg-gradient-to-r from-slate-900/90 via-indigo-950/40 to-slate-900/90 border-slate-800/80'
            : 'bg-gradient-to-r from-indigo-50/80 via-purple-50/40 to-white border-slate-200'
        }`}
      >
        <div className="max-w-2xl relative z-10 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold uppercase tracking-wider">
            <Flame className="w-3.5 h-3.5 text-amber-500" /> Standardized Aptitude Suite
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
            Master Aptitude Across 6 Critical Domains
          </h1>
          <p className={`text-base ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
            Prepare for technical assessments, entrance exams, and placement tests with our built-in pool of 50+ detailed questions covering Quantitative, Reasoning, Verbal, DI, CS, and Spatial logic.
          </p>
          <div className="pt-2 flex flex-wrap gap-4">
            <button
              onClick={() => setCurrentView('generator')}
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold shadow-lg shadow-indigo-500/30 hover:scale-[1.02] transition-transform"
            >
              <Play className="w-4 h-4 fill-white" /> Start Practice Quiz
            </button>
            <button
              onClick={() => setCurrentView('practice')}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl border font-semibold transition-colors ${
                darkMode
                  ? 'border-slate-700 bg-slate-800/50 hover:bg-slate-800'
                  : 'border-slate-300 bg-white hover:bg-slate-100'
              }`}
            >
              <BookOpen className="w-4 h-4" /> Browse All ({dataset.length}) Questions
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Overview Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {[
          { label: 'Quizzes Completed', val: overallStats.totalTaken, icon: CheckCircle2, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
          { label: 'Average Accuracy', val: `${overallStats.avgScore}%`, icon: Award, color: 'text-indigo-400', bg: 'bg-indigo-500/10' },
          { label: 'Best Test Score', val: `${overallStats.bestScore}%`, icon: Flame, color: 'text-amber-400', bg: 'bg-amber-500/10' },
          { label: 'Total Questions Answered', val: overallStats.questionsAnswered, icon: Target, color: 'text-cyan-400', bg: 'bg-cyan-500/10' },
        ].map((stat, i) => {
          const Icon = stat.icon;
          return (
            <div
              key={i}
              className={`p-6 rounded-2xl border backdrop-blur-md flex items-center gap-4 ${
                darkMode
                  ? 'bg-slate-900/60 border-slate-800'
                  : 'bg-white/80 border-slate-200 shadow-sm'
              }`}
            >
              <div className={`p-3 rounded-xl ${stat.bg} ${stat.color}`}>
                <Icon className="w-6 h-6" />
              </div>
              <div>
                <div className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-slate-900'}`}>
                  {stat.val}
                </div>
                <div className={`text-xs ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                  {stat.label}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Recent History & Bookmarks */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Test Attempts History */}
        <div
          className={`lg:col-span-2 p-6 rounded-2xl border backdrop-blur-md space-y-4 ${
            darkMode
              ? 'bg-slate-900/60 border-slate-800'
              : 'bg-white/80 border-slate-200 shadow-sm'
          }`}
        >
          <div className="flex items-center justify-between pb-2 border-b border-slate-700/40">
            <h2 className="text-lg font-bold flex items-center gap-2">
              <Clock className="w-5 h-5 text-indigo-400" /> Recent Test Attempts
            </h2>
            <span className="text-xs text-slate-400">{quizHistory.length} Total</span>
          </div>

          {quizHistory.length === 0 ? (
            <div className="py-12 text-center text-slate-400 space-y-3">
              <Brain className="w-10 h-10 mx-auto stroke-1 opacity-50" />
              <p>No tests taken yet. Launch your first quiz to generate performance analytics!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {quizHistory.slice(0, 5).map((q, idx) => (
                <div
                  key={idx}
                  className={`p-4 rounded-xl border flex items-center justify-between transition-colors ${
                    darkMode
                      ? 'bg-slate-800/40 border-slate-700/50 hover:bg-slate-800/70'
                      : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm">
                        Attempt #{quizHistory.length - idx}
                      </span>
                      <span className="text-xs px-2 py-0.5 rounded bg-slate-700 text-slate-300">
                        {q.date}
                      </span>
                      <span className="text-xs px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 uppercase font-mono">
                        {q.mode}
                      </span>
                    </div>
                    <div className="text-xs text-slate-400 flex items-center gap-3">
                      <span>Questions: {q.total}</span>
                      <span>
                        Time: {Math.floor(q.timeElapsed / 60)}m {q.timeElapsed % 60}s
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="text-lg font-extrabold text-indigo-400">{q.percentage}%</div>
                      <div className="text-xs text-slate-400">
                        {q.score}/{q.total} Correct
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        setLastResults(q);
                        setCurrentView('results');
                      }}
                      className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400 hover:bg-indigo-500/20 transition-colors"
                      title="View Scorecard"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Bookmarked Questions Quick Reference */}
        <div
          className={`p-6 rounded-2xl border backdrop-blur-md space-y-4 ${
            darkMode
              ? 'bg-slate-900/60 border-slate-800'
              : 'bg-white/80 border-slate-200 shadow-sm'
          }`}
        >
          <div className="flex items-center justify-between pb-2 border-b border-slate-700/40">
            <h2 className="text-lg font-bold flex items-center gap-2">
              <Bookmark className="w-5 h-5 text-amber-400" /> Bookmarks ({bookmarks.length})
            </h2>
          </div>

          {bookmarks.length === 0 ? (
            <div className="py-12 text-center text-slate-400 space-y-2">
              <BookmarkCheck className="w-10 h-10 mx-auto stroke-1 opacity-40" />
              <p className="text-sm">No bookmarked questions yet.</p>
            </div>
          ) : (
            <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
              {dataset
                .filter((q) => bookmarks.includes(q.id))
                .map((q) => (
                  <div
                    key={q.id}
                    className={`p-3 rounded-xl border text-xs space-y-2 ${
                      darkMode
                        ? 'bg-slate-800/40 border-slate-700/50'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between text-indigo-400 font-medium">
                      <span>{q.category}</span>
                      <button onClick={() => toggleBookmark(q.id)} className="text-amber-400">
                        <BookmarkCheck className="w-4 h-4 fill-amber-400" />
                      </button>
                    </div>
                    <p className="line-clamp-2 font-medium">{q.question}</p>
                  </div>
                ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
