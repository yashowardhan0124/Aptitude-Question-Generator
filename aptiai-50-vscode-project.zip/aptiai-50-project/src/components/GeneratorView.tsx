import React from 'react';
import { Sparkles, Clock, BookOpen, Play } from 'lucide-react';

interface GeneratorViewProps {
  darkMode: boolean;
  categories: string[];
  quizMode: string;
  setQuizMode: (mode: string) => void;
  genCategory: string;
  setGenCategory: (cat: string) => void;
  genDifficulty: string;
  setGenDifficulty: (diff: string) => void;
  genCount: number;
  setGenCount: (count: number) => void;
  genTimeLimit: number;
  setGenTimeLimit: (time: number) => void;
  isGenerating: boolean;
  handleStartQuiz: () => void;
}

export const GeneratorView: React.FC<GeneratorViewProps> = ({
  darkMode,
  categories,
  quizMode,
  setQuizMode,
  genCategory,
  setGenCategory,
  genDifficulty,
  setGenDifficulty,
  genCount,
  setGenCount,
  genTimeLimit,
  setGenTimeLimit,
  isGenerating,
  handleStartQuiz,
}) => {
  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fadeIn">
      <div
        className={`p-8 rounded-3xl border backdrop-blur-xl space-y-6 ${
          darkMode
            ? 'bg-slate-900/80 border-slate-800'
            : 'bg-white border-slate-200 shadow-lg'
        }`}
      >
        <div className="border-b border-slate-700/50 pb-4 space-y-1">
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-indigo-400" /> AI Quiz Generator Configurator
          </h1>
          <p className="text-sm text-slate-400">
            Select your desired domain, timer settings, and mode to generate a custom test session.
          </p>
        </div>

        <div className="space-y-6">
          {/* Mode Selector (Test vs Practice) */}
          <div>
            <label className="block text-sm font-medium mb-2 text-slate-300">
              Test Execution Mode
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setQuizMode('test')}
                className={`p-4 rounded-2xl border text-left transition-all ${
                  quizMode === 'test'
                    ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300 ring-2 ring-indigo-500/40'
                    : `${
                        darkMode
                          ? 'bg-slate-800/40 border-slate-700 text-slate-400'
                          : 'bg-slate-100 border-slate-200 text-slate-600'
                      }`
                }`}
              >
                <div className="font-bold text-sm flex items-center gap-2">
                  <Clock className="w-4 h-4 text-indigo-400" /> Exam Simulation
                </div>
                <div className="text-xs opacity-75 mt-1">
                  Timed test, solutions hidden until completion.
                </div>
              </button>

              <button
                onClick={() => setQuizMode('practice')}
                className={`p-4 rounded-2xl border text-left transition-all ${
                  quizMode === 'practice'
                    ? 'bg-purple-600/20 border-purple-500 text-purple-300 ring-2 ring-purple-500/40'
                    : `${
                        darkMode
                          ? 'bg-slate-800/40 border-slate-700 text-slate-400'
                          : 'bg-slate-100 border-slate-200 text-slate-600'
                      }`
                }`}
              >
                <div className="font-bold text-sm flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-purple-400" /> Interactive Practice
                </div>
                <div className="text-xs opacity-75 mt-1">
                  Untimed, instant answer feedback & hints per question.
                </div>
              </button>
            </div>
          </div>

          {/* Category Selection */}
          <div>
            <label className="block text-sm font-medium mb-2 text-slate-300">
              Domain / Subject Category
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setGenCategory(cat)}
                  className={`p-3 rounded-xl text-xs font-semibold border text-left transition-all ${
                    genCategory === cat
                      ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300 shadow-sm'
                      : `${
                          darkMode
                            ? 'bg-slate-800/40 border-slate-700 text-slate-400 hover:border-slate-600'
                            : 'bg-slate-100 border-slate-200 text-slate-600'
                        }`
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Difficulty Levels */}
          <div>
            <label className="block text-sm font-medium mb-2 text-slate-300">
              Difficulty Level
            </label>
            <div className="grid grid-cols-4 gap-3">
              {['All', 'Easy', 'Medium', 'Hard'].map((diff) => (
                <button
                  key={diff}
                  onClick={() => setGenDifficulty(diff)}
                  className={`py-2.5 rounded-xl text-xs font-bold border transition-all ${
                    genDifficulty === diff
                      ? 'bg-purple-600/20 border-purple-500 text-purple-300'
                      : `${
                          darkMode
                            ? 'bg-slate-800/40 border-slate-700 text-slate-400'
                            : 'bg-slate-100 border-slate-200 text-slate-600'
                        }`
                  }`}
                >
                  {diff}
                </button>
              ))}
            </div>
          </div>

          {/* Number of Questions & Time Slider */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-sm font-medium mb-2 text-slate-300">
                Question Count ({genCount})
              </label>
              <input
                type="range"
                min="5"
                max="30"
                value={genCount}
                onChange={(e) => setGenCount(Number(e.target.value))}
                className="w-full accent-indigo-500 cursor-pointer"
              />
              <div className="flex justify-between text-xs text-slate-400 mt-1">
                <span>5 Questions</span>
                <span>30 Questions</span>
              </div>
            </div>

            {quizMode === 'test' && (
              <div>
                <label className="block text-sm font-medium mb-2 text-slate-300">
                  Time Limit ({genTimeLimit === 0 ? 'No Limit' : `${genTimeLimit} Minutes`})
                </label>
                <select
                  value={genTimeLimit}
                  onChange={(e) => setGenTimeLimit(Number(e.target.value))}
                  className={`w-full p-2.5 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                    darkMode
                      ? 'bg-slate-800 border-slate-700 text-white'
                      : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                >
                  <option value={0}>No Timer (Relaxed)</option>
                  <option value={5}>5 Minutes (Sprint)</option>
                  <option value={10}>10 Minutes (Standard)</option>
                  <option value={15}>15 Minutes (Comprehensive)</option>
                  <option value={20}>20 Minutes (Full Length)</option>
                </select>
              </div>
            )}
          </div>
        </div>

        {/* Start Quiz Button */}
        <div className="pt-4 border-t border-slate-700/50">
          <button
            onClick={handleStartQuiz}
            disabled={isGenerating}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 text-white font-bold text-lg shadow-xl shadow-indigo-500/30 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2"
          >
            {isGenerating ? (
              <>
                <Clock className="w-5 h-5 animate-spin" /> Compiling Test Session...
              </>
            ) : (
              <>
                <Play className="w-5 h-5 fill-white" /> Launch Assessment Session
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
