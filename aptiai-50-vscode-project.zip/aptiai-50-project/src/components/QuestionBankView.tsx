import React from 'react';
import { BookOpen, Search, Plus, Bookmark, Download, Upload } from 'lucide-react';
import { Question } from '../types/aptitude';

interface QuestionBankViewProps {
  darkMode: boolean;
  filteredDataset: Question[];
  categories: string[];
  bookmarks: string[];
  toggleBookmark: (id: string) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  practiceCat: string;
  setPracticeCat: (cat: string) => void;
  practiceDiff: string;
  setPracticeDiff: (diff: string) => void;
  handleExportJSON: () => void;
  handleImportJSON: (e: React.ChangeEvent<HTMLInputElement>) => void;
  showAddModal: boolean;
  setShowAddModal: (show: boolean) => void;
  newQ: {
    category: string;
    subCategory: string;
    difficulty: string;
    question: string;
    options: string[];
    correctIndex: number;
    explanation: string;
    formula: string;
  };
  setNewQ: React.Dispatch<
    React.SetStateAction<{
      category: string;
      subCategory: string;
      difficulty: string;
      question: string;
      options: string[];
      correctIndex: number;
      explanation: string;
      formula: string;
    }>
  >;
  handleAddQuestion: (e: React.FormEvent) => void;
}

export const QuestionBankView: React.FC<QuestionBankViewProps> = ({
  darkMode,
  filteredDataset,
  categories,
  bookmarks,
  toggleBookmark,
  searchQuery,
  setSearchQuery,
  practiceCat,
  setPracticeCat,
  practiceDiff,
  setPracticeDiff,
  handleExportJSON,
  handleImportJSON,
  showAddModal,
  setShowAddModal,
  newQ,
  setNewQ,
  handleAddQuestion,
}) => {
  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Action Bar: Custom Add & Import/Export */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-indigo-400" /> Question Bank Explorer (
            {filteredDataset.length})
          </h1>
          <p className="text-xs text-slate-400">
            Search, filter, practice, or expand your dataset with JSON bulk load.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleExportJSON}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-300 hover:text-white text-xs font-semibold"
            title="Export entire question bank as JSON"
          >
            <Download className="w-4 h-4" /> Export JSON
          </button>

          <label className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-300 hover:text-white text-xs font-semibold cursor-pointer">
            <Upload className="w-4 h-4" /> Import JSON
            <input type="file" accept=".json" onChange={handleImportJSON} className="hidden" />
          </label>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md transition-all"
          >
            <Plus className="w-4 h-4" /> Add Question
          </button>
        </div>
      </div>

      {/* Filter controls */}
      <div
        className={`p-4 rounded-2xl border backdrop-blur-md grid grid-cols-1 sm:grid-cols-3 gap-3 ${
          darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            placeholder="Search questions or formulas..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full pl-9 pr-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
              darkMode
                ? 'bg-slate-800 border-slate-700 text-white'
                : 'bg-slate-50 border-slate-200 text-slate-900'
            }`}
          />
        </div>

        <select
          value={practiceCat}
          onChange={(e) => setPracticeCat(e.target.value)}
          className={`p-2 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
            darkMode
              ? 'bg-slate-800 border-slate-700 text-white'
              : 'bg-slate-50 border-slate-200 text-slate-900'
          }`}
        >
          <option value="All">All Categories</option>
          {categories
            .filter((c) => c !== 'All Categories')
            .map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
        </select>

        <select
          value={practiceDiff}
          onChange={(e) => setPracticeDiff(e.target.value)}
          className={`p-2 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
            darkMode
              ? 'bg-slate-800 border-slate-700 text-white'
              : 'bg-slate-50 border-slate-200 text-slate-900'
          }`}
        >
          <option value="All">All Difficulties</option>
          <option value="Easy">Easy</option>
          <option value="Medium">Medium</option>
          <option value="Hard">Hard</option>
        </select>
      </div>

      {/* Question Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredDataset.map((q) => {
          const isBookmarked = bookmarks.includes(q.id);
          return (
            <div
              key={q.id}
              className={`p-5 rounded-2xl border backdrop-blur-md space-y-3 flex flex-col justify-between ${
                darkMode
                  ? 'bg-slate-900/60 border-slate-800'
                  : 'bg-white border-slate-200 shadow-sm'
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-indigo-400">{q.category}</span>
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2 py-0.5 rounded font-semibold ${
                        q.difficulty === 'Easy'
                          ? 'bg-emerald-500/10 text-emerald-400'
                          : q.difficulty === 'Medium'
                          ? 'bg-amber-500/10 text-amber-400'
                          : 'bg-rose-500/10 text-rose-400'
                      }`}
                    >
                      {q.difficulty}
                    </span>
                    <button onClick={() => toggleBookmark(q.id)} className="text-amber-400">
                      <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-amber-400' : ''}`} />
                    </button>
                  </div>
                </div>

                <p className="font-semibold text-sm leading-snug whitespace-pre-line">
                  {q.question}
                </p>
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-800/60">
                <div className="text-xs text-slate-400">
                  <span className="font-semibold text-emerald-400">Correct Answer:</span>{' '}
                  {q.options[q.correctIndex]}
                </div>
                <details className="text-xs text-slate-400 cursor-pointer">
                  <summary className="font-semibold text-indigo-400 hover:underline">
                    View Detailed Solution
                  </summary>
                  <p className="mt-2 p-2.5 rounded-lg bg-slate-950/60 border border-slate-800 text-slate-300 whitespace-pre-line">
                    {q.explanation}
                  </p>
                </details>
              </div>
            </div>
          );
        })}
      </div>

      {/* MODAL: ADD CUSTOM QUESTION */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div
            className={`max-w-xl w-full p-6 rounded-3xl border space-y-4 max-h-[90vh] overflow-y-auto ${
              darkMode
                ? 'bg-slate-900 border-slate-800 text-white'
                : 'bg-white border-slate-200'
            }`}
          >
            <div className="flex items-center justify-between border-b border-slate-700/50 pb-3">
              <h3 className="font-bold text-lg flex items-center gap-2">
                <Plus className="w-5 h-5 text-indigo-400" /> Add Custom Question
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddQuestion} className="space-y-4 text-xs">
              <div>
                <label className="block mb-1 font-semibold text-slate-300">Domain Category</label>
                <select
                  value={newQ.category}
                  onChange={(e) => setNewQ({ ...newQ, category: e.target.value })}
                  className="w-full p-2.5 rounded-xl border bg-slate-800 border-slate-700 text-white"
                >
                  <option value="Quantitative Aptitude">Quantitative Aptitude</option>
                  <option value="Logical Reasoning">Logical Reasoning</option>
                  <option value="Verbal Ability">Verbal Ability</option>
                  <option value="Data Interpretation">Data Interpretation</option>
                  <option value="Computer & Coding Concepts">Computer & Coding Concepts</option>
                  <option value="Spatial & Abstract Reasoning">Spatial & Abstract Reasoning</option>
                </select>
              </div>

              <div>
                <label className="block mb-1 font-semibold text-slate-300">Question Prompt</label>
                <textarea
                  rows={3}
                  value={newQ.question}
                  onChange={(e) => setNewQ({ ...newQ, question: e.target.value })}
                  className="w-full p-2.5 rounded-xl border bg-slate-800 border-slate-700 text-white"
                  required
                />
              </div>

              <div className="space-y-2">
                <label className="block font-semibold text-slate-300">
                  Options (Select radio for correct answer)
                </label>
                {newQ.options.map((opt, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <input
                      type="radio"
                      name="correctOpt"
                      checked={newQ.correctIndex === i}
                      onChange={() => setNewQ({ ...newQ, correctIndex: i })}
                      className="accent-indigo-500"
                    />
                    <input
                      type="text"
                      placeholder={`Option ${String.fromCharCode(65 + i)}`}
                      value={opt}
                      onChange={(e) => {
                        const updated = [...newQ.options];
                        updated[i] = e.target.value;
                        setNewQ({ ...newQ, options: updated });
                      }}
                      className="w-full p-2 rounded-xl border bg-slate-800 border-slate-700 text-white"
                      required
                    />
                  </div>
                ))}
              </div>

              <div>
                <label className="block mb-1 font-semibold text-slate-300">
                  Step-by-Step Explanation
                </label>
                <textarea
                  rows={2}
                  value={newQ.explanation}
                  onChange={(e) => setNewQ({ ...newQ, explanation: e.target.value })}
                  className="w-full p-2.5 rounded-xl border bg-slate-800 border-slate-700 text-white"
                />
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-700 text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 text-white font-bold"
                >
                  Save Question
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
