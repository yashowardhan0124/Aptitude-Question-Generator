import React from 'react';
import {
  CheckCircle2,
  XCircle,
  Clock,
  Bookmark,
  Lightbulb,
  ChevronRight,
  ChevronLeft,
} from 'lucide-react';
import { QuizSession } from '../types/aptitude';

interface QuizPlayerViewProps {
  darkMode: boolean;
  activeQuiz: QuizSession;
  currentQIndex: number;
  setCurrentQIndex: React.Dispatch<React.SetStateAction<number>>;
  bookmarks: string[];
  toggleBookmark: (id: string) => void;
  handleSelectOption: (idx: number) => void;
  finishQuiz: () => void;
  hintModalOpen: boolean;
  setHintModalOpen: (open: boolean) => void;
}

export const QuizPlayerView: React.FC<QuizPlayerViewProps> = ({
  darkMode,
  activeQuiz,
  currentQIndex,
  setCurrentQIndex,
  bookmarks,
  toggleBookmark,
  handleSelectOption,
  finishQuiz,
  hintModalOpen,
  setHintModalOpen,
}) => {
  const q = activeQuiz.questions[currentQIndex];
  const selectedOpt = activeQuiz.userAnswers[currentQIndex];
  const isBookmarked = bookmarks.includes(q.id);
  const showInstantFeedback = activeQuiz.mode === 'practice' && selectedOpt !== null;

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fadeIn">
      {/* Top Bar: Progress & Timer */}
      <div
        className={`p-4 rounded-2xl border backdrop-blur-md flex items-center justify-between ${
          darkMode
            ? 'bg-slate-900/70 border-slate-800'
            : 'bg-white border-slate-200 shadow-sm'
        }`}
      >
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 font-mono">
            Q {currentQIndex + 1} / {activeQuiz.questions.length}
          </span>
          <span className="text-xs text-slate-400 font-medium hidden sm:inline">
            {q.category}
          </span>
        </div>

        {/* Timer Display for Test Mode */}
        {activeQuiz.mode === 'test' && activeQuiz.timeLimit > 0 && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-mono font-bold">
            <Clock className="w-4 h-4 animate-pulse" />
            {Math.floor((activeQuiz.timeLimit * 60 - activeQuiz.timeElapsed) / 60)}:
            {String((activeQuiz.timeLimit * 60 - activeQuiz.timeElapsed) % 60).padStart(2, '0')}
          </div>
        )}

        <button
          onClick={() => {
            if (confirm('Submit quiz and view scorecard now?')) {
              finishQuiz();
            }
          }}
          className="px-3 py-1.5 rounded-xl text-xs font-semibold text-rose-400 bg-rose-500/10 border border-rose-500/20 hover:bg-rose-500/20 transition-colors"
        >
          Submit Early
        </button>
      </div>

      {/* Main Question Card */}
      <div
        className={`p-6 sm:p-8 rounded-3xl border backdrop-blur-xl space-y-6 ${
          darkMode
            ? 'bg-slate-900/80 border-slate-800'
            : 'bg-white border-slate-200 shadow-xl'
        }`}
      >
        {/* Meta badges & Bookmark */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span
              className={`text-xs px-2.5 py-1 rounded-full font-bold ${
                q.difficulty === 'Easy'
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                  : q.difficulty === 'Medium'
                  ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                  : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
              }`}
            >
              {q.difficulty}
            </span>
            <span className="text-xs text-slate-400 font-medium">{q.subCategory}</span>
          </div>

          <button
            onClick={() => toggleBookmark(q.id)}
            className={`p-2 rounded-xl transition-colors ${
              isBookmarked
                ? 'bg-amber-500/20 text-amber-400'
                : 'bg-slate-800/50 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-amber-400' : ''}`} />
          </button>
        </div>

        {/* Question Stem */}
        <h2
          className={`text-lg sm:text-xl font-bold leading-relaxed whitespace-pre-line ${
            darkMode ? 'text-slate-100' : 'text-slate-900'
          }`}
        >
          {q.question}
        </h2>

        {/* Options Grid */}
        <div className="space-y-3 pt-2">
          {q.options.map((opt, idx) => {
            const isSelected = selectedOpt === idx;
            const isCorrectChoice = q.correctIndex === idx;

            let optStyling = darkMode
              ? 'bg-slate-800/40 border-slate-700/70 hover:bg-slate-800 text-slate-200'
              : 'bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-800';

            if (showInstantFeedback) {
              if (isCorrectChoice) {
                optStyling =
                  'bg-emerald-500/20 border-emerald-500/50 text-emerald-200 font-semibold ring-1 ring-emerald-500/50';
              } else if (isSelected) {
                optStyling =
                  'bg-rose-500/20 border-rose-500/50 text-rose-200 font-semibold ring-1 ring-rose-500/50';
              }
            } else if (isSelected) {
              optStyling =
                'bg-indigo-600/20 border-indigo-500 text-indigo-200 ring-2 ring-indigo-500/40 font-semibold';
            }

            return (
              <button
                key={idx}
                onClick={() => handleSelectOption(idx)}
                className={`w-full p-4 rounded-2xl border text-left flex items-center justify-between transition-all duration-200 ${optStyling}`}
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`w-7 h-7 rounded-lg flex items-center justify-center font-semibold text-xs ${
                      isSelected ? 'bg-indigo-500 text-white' : 'bg-slate-700/50 text-slate-300'
                    }`}
                  >
                    {String.fromCharCode(65 + idx)}
                  </span>
                  <span className="text-sm">{opt}</span>
                </div>
                {showInstantFeedback && isCorrectChoice && (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                )}
                {showInstantFeedback && isSelected && !isCorrectChoice && (
                  <XCircle className="w-5 h-5 text-rose-400" />
                )}
              </button>
            );
          })}
        </div>

        {/* Instant Practice Explanation Box */}
        {showInstantFeedback && (
          <div className="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 text-xs space-y-2 animate-fadeIn">
            <div className="font-bold text-indigo-300 flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-amber-400" /> Explanation & Formula:
            </div>
            <p className="text-slate-300 leading-relaxed whitespace-pre-line">{q.explanation}</p>
          </div>
        )}

        {/* Bottom Navigation Controls */}
        <div className="pt-6 border-t border-slate-700/50 flex flex-wrap items-center justify-between gap-4">
          <button
            onClick={() => setHintModalOpen(true)}
            className="flex items-center gap-2 text-xs font-semibold text-amber-400 bg-amber-500/10 px-3.5 py-2 rounded-xl border border-amber-500/20 hover:bg-amber-500/20 transition-colors"
          >
            <Lightbulb className="w-4 h-4" /> Hint / Key Formula
          </button>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setCurrentQIndex((prev) => Math.max(0, prev - 1))}
              disabled={currentQIndex === 0}
              className="p-2.5 rounded-xl border border-slate-700 disabled:opacity-40 hover:bg-slate-800 transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            {currentQIndex === activeQuiz.questions.length - 1 ? (
              <button
                onClick={() => finishQuiz()}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold text-sm shadow-lg shadow-emerald-500/20 hover:scale-[1.02] transition-transform"
              >
                Complete Assessment
              </button>
            ) : (
              <button
                onClick={() => setCurrentQIndex((prev) => prev + 1)}
                className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-lg shadow-indigo-500/20 flex items-center gap-2 transition-colors"
              >
                Next <ChevronRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* HINT POPUP MODAL */}
      {hintModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div
            className={`max-w-md w-full p-6 rounded-3xl border space-y-4 ${
              darkMode
                ? 'bg-slate-900 border-slate-800 text-white'
                : 'bg-white border-slate-200'
            }`}
          >
            <div className="flex items-center justify-between border-b border-slate-700/50 pb-3">
              <h3 className="font-bold flex items-center gap-2 text-amber-400">
                <Lightbulb className="w-5 h-5" /> Formula & Logic Hint
              </h3>
              <button
                onClick={() => setHintModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>
            <p className="text-sm text-slate-300 font-mono">
              {q.formula || 'Deconstruct the options using standard logical elimination rules.'}
            </p>
            <button
              onClick={() => setHintModalOpen(false)}
              className="w-full py-2.5 rounded-xl bg-slate-800 text-xs font-bold text-slate-200 hover:bg-slate-700"
            >
              Close Hint
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
