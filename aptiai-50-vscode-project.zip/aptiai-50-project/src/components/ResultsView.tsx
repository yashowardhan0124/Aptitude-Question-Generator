import React from 'react';
import { FileText, Check, XCircle } from 'lucide-react';
import { CompletedResult } from '../types/aptitude';

interface ResultsViewProps {
  darkMode: boolean;
  lastResults: CompletedResult;
  setCurrentView: (view: string) => void;
}

export const ResultsView: React.FC<ResultsViewProps> = ({
  darkMode,
  lastResults,
  setCurrentView,
}) => {
  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fadeIn">
      {/* Scorecard Overview Card */}
      <div
        className={`p-8 rounded-3xl border backdrop-blur-xl text-center space-y-4 relative overflow-hidden ${
          darkMode
            ? 'bg-slate-900/80 border-slate-800'
            : 'bg-white border-slate-200 shadow-xl'
        }`}
      >
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 text-xs font-bold uppercase tracking-wider">
          Performance Scorecard
        </div>
        <h1 className="text-3xl font-extrabold">Assessment Finished!</h1>

        <div className="flex justify-center items-center py-4">
          <div className="relative w-36 h-36 flex items-center justify-center rounded-full border-4 border-indigo-500/30 bg-indigo-500/5">
            <div className="text-center">
              <span className="text-4xl font-black text-indigo-400">
                {lastResults.percentage}%
              </span>
              <div className="text-xs text-slate-400 font-medium">Final Accuracy</div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 max-w-md mx-auto pt-2">
          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-lg font-bold text-emerald-400">{lastResults.score}</div>
            <div className="text-xs text-slate-400">Correct</div>
          </div>
          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-lg font-bold text-rose-400">
              {lastResults.total - lastResults.score}
            </div>
            <div className="text-xs text-slate-400">Incorrect</div>
          </div>
          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-lg font-bold text-cyan-400">
              {Math.floor(lastResults.timeElapsed / 60)}m {lastResults.timeElapsed % 60}s
            </div>
            <div className="text-xs text-slate-400">Time Spent</div>
          </div>
        </div>

        <div className="pt-4 flex justify-center gap-4">
          <button
            onClick={() => setCurrentView('generator')}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-bold text-sm shadow-md"
          >
            Generate Another Test
          </button>
        </div>
      </div>

      {/* Detailed Questions Solution Breakdown */}
      <div
        className={`p-6 sm:p-8 rounded-3xl border backdrop-blur-xl space-y-6 ${
          darkMode
            ? 'bg-slate-900/80 border-slate-800'
            : 'bg-white border-slate-200 shadow-xl'
        }`}
      >
        <h2 className="text-xl font-bold flex items-center gap-2 border-b border-slate-700/50 pb-4">
          <FileText className="w-5 h-5 text-indigo-400" /> Complete Solution & Logic Key
        </h2>

        <div className="space-y-6">
          {lastResults.questions.map((q, idx) => {
            const uAns = lastResults.userAnswers[idx];
            const isCorrect = uAns === q.correctIndex;

            return (
              <div
                key={idx}
                className={`p-5 rounded-2xl border space-y-3 ${
                  isCorrect
                    ? 'bg-emerald-950/10 border-emerald-500/30'
                    : 'bg-rose-950/10 border-rose-500/30'
                }`}
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-400">
                    Question {idx + 1} ({q.category})
                  </span>
                  <span
                    className={`px-2.5 py-0.5 rounded-md font-semibold ${
                      isCorrect
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : 'bg-rose-500/20 text-rose-400'
                    }`}
                  >
                    {isCorrect ? 'Correct' : 'Incorrect'}
                  </span>
                </div>

                <p className="font-bold text-sm leading-relaxed whitespace-pre-line">
                  {q.question}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {q.options.map((opt, oIdx) => {
                    const isUserSelection = uAns === oIdx;
                    const isAnswerKey = q.correctIndex === oIdx;

                    return (
                      <div
                        key={oIdx}
                        className={`p-2.5 rounded-xl border flex items-center justify-between ${
                          isAnswerKey
                            ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-200 font-medium'
                            : isUserSelection
                            ? 'bg-rose-500/20 border-rose-500/40 text-rose-200 font-medium'
                            : 'bg-slate-800/30 border-slate-700/40 text-slate-400'
                        }`}
                      >
                        <span>
                          {String.fromCharCode(65 + oIdx)}. {opt}
                        </span>
                        {isAnswerKey && <Check className="w-4 h-4 text-emerald-400" />}
                        {isUserSelection && !isAnswerKey && (
                          <XCircle className="w-4 h-4 text-rose-400" />
                        )}
                      </div>
                    );
                  })}
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 text-xs space-y-1">
                  <span className="font-bold text-indigo-400 block">
                    Step-by-Step Solution Breakdown:
                  </span>
                  <p className="text-slate-300 leading-relaxed whitespace-pre-line">
                    {q.explanation}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
