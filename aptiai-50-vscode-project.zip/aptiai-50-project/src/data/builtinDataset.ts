import { Question } from '../types/aptitude';

export const BUILTIN_DATASET: Question[] = [
  // -------------------------------------------------------------
  // 1. QUANTITATIVE APTITUDE (12 Questions)
  // -------------------------------------------------------------
  {
    id: "quant_1",
    category: "Quantitative Aptitude",
    subCategory: "Work & Time",
    difficulty: "Medium",
    question: "A can complete a piece of work in 12 days, and B can complete the same work in 18 days. If they work together for 4 days, what fraction of the total work remains unfinished?",
    options: ["1/9", "4/9", "5/9", "2/3"],
    correctIndex: 1,
    explanation: "A's 1-day rate = 1/12. B's 1-day rate = 1/18.\nTogether in 1 day = 1/12 + 1/18 = (3 + 2)/36 = 5/36.\nIn 4 days, work completed = 4 × (5/36) = 20/36 = 5/9.\nFraction of work left = 1 - 5/9 = 4/9.",
    formula: "Work Left = 1 - (Rate_A + Rate_B) × Time"
  },
  {
    id: "quant_2",
    category: "Quantitative Aptitude",
    subCategory: "Profit & Loss",
    difficulty: "Easy",
    question: "A merchant buys a gadget for $80 and sells it for $100. Later, he buys it back for $110 and sells it again for $130. What is his net profit overall?",
    options: ["$20", "$30", "$40", "$50"],
    correctIndex: 2,
    explanation: "Transaction 1: Profit = $100 - $80 = $20.\nTransaction 2: Profit = $130 - $110 = $20.\nNet total profit = $20 + $20 = $40.",
    formula: "Total Profit = Sum of individual (Selling Price - Cost Price)"
  },
  {
    id: "quant_3",
    category: "Quantitative Aptitude",
    subCategory: "Percentages & Interest",
    difficulty: "Hard",
    question: "The simple interest on a sum of money for 3 years at 8% per annum is $240. What would be the compound interest on the same sum for 2 years at 10% per annum compounded annually?",
    options: ["$200", "$210", "$220", "$240"],
    correctIndex: 1,
    explanation: "Simple Interest SI = (P × R × T) / 100\n240 = (P × 8 × 3) / 100  =>  240 = 24P / 100  =>  P = $1000.\nCompound Interest CI = P(1 + R/100)^n - P\nCI = 1000(1 + 10/100)^2 - 1000 = 1000(1.21) - 1000 = $1210 - $1000 = $210.",
    formula: "SI = (P×R×T)/100; CI = P(1 + R/100)ⁿ - P"
  },
  {
    id: "quant_4",
    category: "Quantitative Aptitude",
    subCategory: "Speed & Distance",
    difficulty: "Medium",
    question: "A train 150 meters long passes a telegraph pole in 9 seconds. What is the speed of the train in km/hr?",
    options: ["50 km/hr", "60 km/hr", "65 km/hr", "70 km/hr"],
    correctIndex: 1,
    explanation: "Speed in m/s = Distance / Time = 150 m / 9 s = 50/3 m/s.\nConvert to km/hr by multiplying by (18/5):\nSpeed = (50/3) × (18/5) = 10 × 6 = 60 km/hr.",
    formula: "Speed (km/h) = Speed (m/s) × 18 / 5"
  },
  {
    id: "quant_5",
    category: "Quantitative Aptitude",
    subCategory: "Ratio & Proportion",
    difficulty: "Medium",
    question: "In a 60-liter mixture of milk and water, the ratio of milk to water is 2:1. How many liters of water must be added to make the ratio 1:2?",
    options: ["40 liters", "60 liters", "80 liters", "30 liters"],
    correctIndex: 1,
    explanation: "Milk volume = (2/3) × 60 = 40L, Water volume = 20L.\nLet 'x' liters of water be added.\nNew ratio: Milk / (Water + x) = 1 / 2\n40 / (20 + x) = 1/2  =>  80 = 20 + x  =>  x = 60 liters.",
    formula: "Part = Total × (Ratio Component / Total Ratio Parts)"
  },
  {
    id: "quant_6",
    category: "Quantitative Aptitude",
    subCategory: "Averages",
    difficulty: "Easy",
    question: "The average age of a group of 20 students is 15 years. If the teacher's age is included, the average increases by 1 year. What is the teacher's age?",
    options: ["35 years", "36 years", "40 years", "42 years"],
    correctIndex: 1,
    explanation: "Total age of 20 students = 20 × 15 = 300.\nNew total count = 21, new average = 16.\nTotal age of 21 people = 21 × 16 = 336.\nTeacher's age = 336 - 300 = 36 years.",
    formula: "New Value = (New Count × New Avg) - (Old Count × Old Avg)"
  },
  {
    id: "quant_7",
    category: "Quantitative Aptitude",
    subCategory: "Permutation & Combination",
    difficulty: "Hard",
    question: "In how many distinct ways can the letters of the word 'LEADER' be arranged such that all the vowels always remain together?",
    options: ["72", "108", "144", "360"],
    correctIndex: 0,
    explanation: "Vowels in LEADER: E, A, E (3 vowels). Consonants: L, D, R (3 consonants).\nTreat vowels as 1 single block: (EAE) + L + D + R = 4 distinct units.\nNumber of arrangements of 4 units = 4! = 24.\nWithin the vowel block (E, A, E), arrangements = 3! / 2! (since E repeats twice) = 3.\nTotal distinct ways = 24 × 3 = 72.",
    formula: "Permutations with duplicate elements = n! / (p! × q!)"
  },
  {
    id: "quant_8",
    category: "Quantitative Aptitude",
    subCategory: "Probability",
    difficulty: "Medium",
    question: "Two cards are drawn at random from a standard 52-card deck without replacement. What is the probability that both drawn cards are Aces?",
    options: ["1/221", "4/663", "1/169", "1/26"],
    correctIndex: 0,
    explanation: "P(1st Ace) = 4 / 52 = 1 / 13.\nP(2nd Ace | 1st Ace) = 3 / 51 = 1 / 17.\nCombined Probability = (1/13) × (1/17) = 1 / 221.",
    formula: "P(A ∩ B) = P(A) × P(B | A)"
  },
  {
    id: "quant_9",
    category: "Quantitative Aptitude",
    subCategory: "Permutation & Combination",
    difficulty: "Medium",
    question: "How many handshakes take place in a room of 10 people if every person shakes hands with every other person exactly once?",
    options: ["90", "45", "50", "36"],
    correctIndex: 1,
    explanation: "Each handshake involves a combination of 2 people out of 10.\nComb(10, 2) = (10 × 9) / (2 × 1) = 45 handshakes.",
    formula: "Combinations nC2 = n × (n - 1) / 2"
  },
  {
    id: "quant_10",
    category: "Quantitative Aptitude",
    subCategory: "Work & Time",
    difficulty: "Hard",
    question: "Pipes A and B can fill a tank in 10 and 15 hours respectively, while Pipe C can empty it in 20 hours. If all three pipes are opened simultaneously, how long will it take to fill the tank?",
    options: ["7.5 hours", "8.57 hours", "9.2 hours", "12 hours"],
    correctIndex: 1,
    explanation: "Net rate per hour = (1/10) + (1/15) - (1/20).\nLCM of 10, 15, 20 = 60.\nNet rate = (6 + 4 - 3) / 60 = 7 / 60 tank per hour.\nTotal time required = 60 / 7 ≈ 8.57 hours.",
    formula: "Combined Rate = Inlet_1 + Inlet_2 - Outlet"
  },
  {
    id: "quant_11",
    category: "Quantitative Aptitude",
    subCategory: "Speed & Distance",
    difficulty: "Easy",
    question: "A runner covers a distance of 200 meters in 24 seconds. What is his speed in kilometers per hour?",
    options: ["28 km/h", "30 km/h", "32 km/h", "35 km/h"],
    correctIndex: 1,
    explanation: "Speed in m/s = 200 / 24 = 25 / 3 m/s.\nConvert to km/h = (25 / 3) × (18 / 5) = 5 × 6 = 30 km/h.",
    formula: "Speed (km/h) = (m/s) × 18/5"
  },
  {
    id: "quant_12",
    category: "Quantitative Aptitude",
    subCategory: "Profit & Loss",
    difficulty: "Medium",
    question: "A vendor marks up an article by 40% above the cost price and allows a discount of 20% on the marked price. What is his net profit percentage?",
    options: ["10%", "12%", "15%", "20%"],
    correctIndex: 1,
    explanation: "Let Cost Price = 100.\nMarked Price = 100 + 40% = 140.\nSelling Price = 140 - (20% of 140) = 140 - 28 = 112.\nProfit = Selling Price - Cost Price = 112 - 100 = 12%.",
    formula: "Net % = Markup% - Discount% - (Markup% × Discount% / 100)"
  },

  // -------------------------------------------------------------
  // 2. LOGICAL REASONING (10 Questions)
  // -------------------------------------------------------------
  {
    id: "logic_1",
    category: "Logical Reasoning",
    subCategory: "Series Completion",
    difficulty: "Medium",
    question: "Determine the missing term in the number series: 2, 6, 12, 20, 30, 42, ?",
    options: ["52", "54", "56", "60"],
    correctIndex: 2,
    explanation: "Differences between consecutive terms: +4, +6, +8, +10, +12.\nNext difference must be +14.\n42 + 14 = 56. (Alternative pattern: n² + n for n = 1, 2, 3... 7² + 7 = 56).",
    formula: "Pattern: n² + n or Difference +2 incremental"
  },
  {
    id: "logic_2",
    category: "Logical Reasoning",
    subCategory: "Blood Relations",
    difficulty: "Easy",
    question: "Pointing to a portrait, a woman says, 'He is the son of the only daughter of my mother.' How is the person in the portrait related to the woman?",
    options: ["Brother", "Son", "Nephew", "Uncle"],
    correctIndex: 1,
    explanation: "'The only daughter of my mother' refers directly to the woman herself.\nHence, 'the son of the only daughter' is her own son.",
    formula: "Deconstruct nested statements from innermost relation outward."
  },
  {
    id: "logic_3",
    category: "Logical Reasoning",
    subCategory: "Coding-Decoding",
    difficulty: "Medium",
    question: "If 'FLOWER' is coded as 'EKNVDQ' in a specific cipher, how will 'GARDEN' be encrypted in the same cipher?",
    options: ["FZQCDM", "FYPBDM", "FZQBDM", "FYQCDM"],
    correctIndex: 0,
    explanation: "Pattern: Each letter is shifted backwards by 1 alphabetical position (-1).\nF->E, L->K, O->N, W->V, E->D, R->Q.\nApplying -1 shift to GARDEN:\nG(-1)=F, A(-1)=Z, R(-1)=Q, D(-1)=C, E(-1)=D, N(-1)=M -> FZQCDM.",
    formula: "Letter Transformation: Index - 1"
  },
  {
    id: "logic_4",
    category: "Logical Reasoning",
    subCategory: "Syllogisms",
    difficulty: "Hard",
    question: "Statements: (1) All cats are dogs. (2) Some dogs are birds.\nConclusions: I. Some cats are birds. II. No cat is a bird.",
    options: ["Only I follows", "Only II follows", "Either I or II follows", "Neither I nor II follows"],
    correctIndex: 2,
    explanation: "No direct connection is guaranteed between 'cats' and 'birds'. However, Conclusion I ('Some') and Conclusion II ('No') form a complementary pair.\nOne of them MUST be true; therefore 'Either I or II follows'.",
    formula: "Complementary Pairs (Some + No) trigger Either-Or rule."
  },
  {
    id: "logic_5",
    category: "Logical Reasoning",
    subCategory: "Seating Arrangement",
    difficulty: "Hard",
    question: "Six people A, B, C, D, E, and F are sitting in a circle facing the center. B is between F and D. E is between A and C. A is to the immediate left of D. Who is sitting opposite to F?",
    options: ["A", "C", "E", "D"],
    correctIndex: 2,
    explanation: "Positioning clockwise:\nD is placed. A is immediate left of D.\nE is between A and C -> positions: C, E, A, D.\nB is between F and D -> positions: C, E, A, D, B, F.\nCircle layout: F is opposite to E.",
    formula: "Circular mapping using relative direction constraints."
  },
  {
    id: "logic_6",
    category: "Logical Reasoning",
    subCategory: "Statement & Assumption",
    difficulty: "Medium",
    question: "Statement: 'Use our online portal to submit job applications for faster processing.'\nAssumption I: Applicants desire faster processing.\nAssumption II: Online processing is faster than manual submission.",
    options: ["Only I is implicit", "Only II is implicit", "Both I and II are implicit", "Neither is implicit"],
    correctIndex: 2,
    explanation: "The advertisement assumes applicants value fast processing (I) and that the advertised online portal actually delivers faster processing (II). Both are implicit assumptions.",
    formula: "Implicit assumptions must directly support the statement's rationale."
  },
  {
    id: "logic_7",
    category: "Logical Reasoning",
    subCategory: "Series Completion",
    difficulty: "Easy",
    question: "Which letter comes next in the letter series: Z, W, T, Q, N, ?",
    options: ["K", "L", "M", "J"],
    correctIndex: 0,
    explanation: "Alphabetical position pattern: Z(26), W(23), T(20), Q(17), N(14).\nPattern subtracts 3 each step: 14 - 3 = 11th letter = K.",
    formula: "Alphabetical Index - 3"
  },
  {
    id: "logic_8",
    category: "Logical Reasoning",
    subCategory: "Blood Relations",
    difficulty: "Medium",
    question: "A is the father of C, but C is not his son. E is the daughter of C. How is E related to A?",
    options: ["Granddaughter", "Daughter", "Niece", "Mother"],
    correctIndex: 0,
    explanation: "Since A is the father of C, but C is not his son, C must be A's daughter.\nE is C's daughter. Therefore, E is the granddaughter of A.",
    formula: "Generational mapping: Daughter's daughter = Granddaughter"
  },
  {
    id: "logic_9",
    category: "Logical Reasoning",
    subCategory: "Coding-Decoding",
    difficulty: "Hard",
    question: "If 'COMPUTER' is written as 'RFUVQNPC', how is 'MEDICINE' written in that same code?",
    options: ["EOJDEJFM", "EOJDJEFM", "MFEDJJOE", "EOJDEJFM"],
    correctIndex: 1,
    explanation: "Reverse order of letters in word: R E T U P M O C.\nThen shift inner letters by +1 while keeping ends intact:\nResult for MEDICINE -> E O J D J E F M.",
    formula: "Reverse string order + Shift interior characters by +1"
  },
  {
    id: "logic_10",
    category: "Logical Reasoning",
    subCategory: "Syllogisms",
    difficulty: "Medium",
    question: "Statements: All apples are fruits. All fruits are healthy.\nConclusions: I. All apples are healthy. II. Some healthy things are apples.",
    options: ["Only I follows", "Only II follows", "Both I and II follow", "Neither follows"],
    correctIndex: 2,
    explanation: "All apples ⊆ fruits ⊆ healthy things.\nTherefore, all apples are healthy (I) and some healthy things are apples (II). Both follow.",
    formula: "Venn Subsets: A ⊆ B and B ⊆ C ⇒ A ⊆ C"
  },

  // -------------------------------------------------------------
  // 3. VERBAL ABILITY (10 Questions)
  // -------------------------------------------------------------
  {
    id: "verb_1",
    category: "Verbal Ability",
    subCategory: "Synonyms & Antonyms",
    difficulty: "Easy",
    question: "Choose the word most nearly OPPOSITE in meaning to the word 'METICULOUS':",
    options: ["Careful", "Careless", "Thorough", "Detailed"],
    correctIndex: 1,
    explanation: "'Meticulous' means showing great attention to detail or being precise.\nThe exact antonym is 'Careless'.",
    formula: "Antonym identification"
  },
  {
    id: "verb_2",
    category: "Verbal Ability",
    subCategory: "Error Spotting",
    difficulty: "Medium",
    question: "Identify the part of the sentence with a grammatical error: 'Neither the manager nor the employees was present at the conference.'",
    options: ["Neither the manager", "nor the employees", "was present", "at the conference"],
    correctIndex: 2,
    explanation: "When subjects are joined by 'neither... nor', the verb must agree with the subject closest to it. 'Employees' is plural, so it should be 'were present' instead of 'was present'.",
    formula: "Proximity rule for Subject-Verb Agreement with 'Neither... Nor'"
  },
  {
    id: "verb_3",
    category: "Verbal Ability",
    subCategory: "Sentence Improvement",
    difficulty: "Medium",
    question: "Despite his ______ demeanor, he managed to forge strong alliances across rival political parties.",
    options: ["gregarious", "introverted", "affable", "extroverted"],
    correctIndex: 1,
    explanation: "The word 'Despite' signals a contrast. Forming strong alliances is unexpected for an 'introverted' or quiet personality.",
    formula: "Contrast markers ('Despite', 'Although') require opposite tone words."
  },
  {
    id: "verb_4",
    category: "Verbal Ability",
    subCategory: "Idioms & Phrases",
    difficulty: "Easy",
    question: "What is the true meaning of the idiom 'To burn the midnight oil'?",
    options: ["To waste resources", "To work or study late into the night", "To set something on fire", "To cause an accidental debate"],
    correctIndex: 1,
    explanation: "'To burn the midnight oil' historically refers to burning an oil lamp to work or study late into the night.",
    formula: "Idiomatic definition"
  },
  {
    id: "verb_5",
    category: "Verbal Ability",
    subCategory: "Reading Comprehension",
    difficulty: "Hard",
    question: "Passage: 'Artificial Intelligence algorithms learn patterns from empirical training data. However, when training sets contain implicit human biases, models perpetuate systemic inequities.' What is the author's primary warning?",
    options: ["AI models are fundamentally incapable of learning", "Empirical data is impossible to gather", "Biased training data causes AI to replicate human inequities", "AI will completely eliminate human jobs"],
    correctIndex: 2,
    explanation: "The text directly states that when training data contains human biases, AI algorithms perpetuate systemic inequities.",
    formula: "Extract core thesis from text snippet"
  },
  {
    id: "verb_6",
    category: "Verbal Ability",
    subCategory: "Synonyms & Antonyms",
    difficulty: "Medium",
    question: "Select the word that is closest in SYNONYM meaning to 'PRAGMATIC':",
    options: ["Idealistic", "Practical", "Theoretical", "Irrational"],
    correctIndex: 1,
    explanation: "'Pragmatic' means dealing with things sensibly and realistically based on practical considerations.",
    formula: "Synonym matching"
  },
  {
    id: "verb_7",
    category: "Verbal Ability",
    subCategory: "Error Spotting",
    difficulty: "Medium",
    question: "Spot the error: 'Each of the candidates have submitted their portfolio prior to the deadline.'",
    options: ["Each of the candidates", "have submitted", "their portfolio", "prior to the deadline"],
    correctIndex: 1,
    explanation: "'Each' is a singular indefinite pronoun. Therefore, it requires the singular auxiliary verb 'has submitted' instead of 'have submitted'.",
    formula: "Distributive Pronoun 'Each' takes a singular verb."
  },
  {
    id: "verb_8",
    category: "Verbal Ability",
    subCategory: "Sentence Improvement",
    difficulty: "Hard",
    question: "Replace the underlined clause: 'Had I known about the storm, I would not have started the journey.'",
    options: ["If I knew about the storm", "Had I known about the storm (No change needed)", "If I have known the storm", "Should I know about the storm"],
    correctIndex: 1,
    explanation: "The third conditional structure 'Had I known..., I would not have...' is grammatically perfect and requires no change.",
    formula: "Inverted 3rd Conditional: Had + Subject + Past Participle"
  },
  {
    id: "verb_9",
    category: "Verbal Ability",
    subCategory: "Idioms & Phrases",
    difficulty: "Easy",
    question: "What does the phrase 'Throw in the towel' mean?",
    options: ["To start a fight", "To clean up", "To surrender or give up", "To celebrate a victory"],
    correctIndex: 2,
    explanation: "Originating from boxing, throwing a towel into the ring signifies admitting defeat or surrendering.",
    formula: "Idiom origin: Boxing surrender"
  },
  {
    id: "verb_10",
    category: "Verbal Ability",
    subCategory: "Reading Comprehension",
    difficulty: "Medium",
    question: "Choose the word that BEST completes the sentence: 'The CEO's speech was so ______ that even non-technical staff understood the core strategy.'",
    options: ["obscure", "lucid", "convoluted", "ambiguous"],
    correctIndex: 1,
    explanation: "'Lucid' means expressed clearly and easy to understand, matching the context of non-technical staff comprehending technical strategy.",
    formula: "Contextual vocabulary mapping"
  },

  // -------------------------------------------------------------
  // 4. DATA INTERPRETATION (8 Questions)
  // -------------------------------------------------------------
  {
    id: "di_1",
    category: "Data Interpretation",
    subCategory: "Table Data",
    difficulty: "Medium",
    question: "Company Profit Data over 3 quarters: Q1 = $120k, Q2 = $150k, Q3 = $180k. What is the overall percentage growth in profit from Q1 to Q3?",
    options: ["33.3%", "40.0%", "50.0%", "60.0%"],
    correctIndex: 2,
    explanation: "Growth amount = Q3 - Q1 = $180k - $120k = $60k.\nPercentage growth = (Growth / Initial Q1 Value) × 100\nPercentage growth = ($60k / $120k) × 100 = 50%.",
    formula: "% Change = [(Final - Initial) / Initial] × 100"
  },
  {
    id: "di_2",
    category: "Data Interpretation",
    subCategory: "Pie Charts",
    difficulty: "Hard",
    question: "In a pie chart representing a total company budget of $360,000, the Marketing sector corresponds to an angle of 75 degrees. How much money is allocated to Marketing?",
    options: ["$60,000", "$75,000", "$80,000", "$90,000"],
    correctIndex: 1,
    explanation: "Total circular angle = 360 degrees = $360,000 total budget.\nValue per degree = $360,000 / 360 = $1,000 per degree.\nMarketing Budget = 75 degrees × $1,000 = $75,000.",
    formula: "Sector Value = Total Value × (Angle / 360°)"
  },
  {
    id: "di_3",
    category: "Data Interpretation",
    subCategory: "Bar Graphs",
    difficulty: "Easy",
    question: "Yearly sales figures (in units): 2020=400, 2021=600, 2022=800, 2023=1000. What is the average yearly sales over this 4-year period?",
    options: ["650 units", "700 units", "750 units", "800 units"],
    correctIndex: 1,
    explanation: "Sum of sales = 400 + 600 + 800 + 1000 = 2800 units.\nAverage = Sum / 4 = 2800 / 4 = 700 units per year.",
    formula: "Average = Total Sum / Count"
  },
  {
    id: "di_4",
    category: "Data Interpretation",
    subCategory: "Data Sufficiency",
    difficulty: "Hard",
    question: "Question: Is integer 'x' even?\nStatement (1): x + 3 is odd.\nStatement (2): 2x is even.\nWhich statements are sufficient?",
    options: ["Statement (1) ALONE is sufficient", "Statement (2) ALONE is sufficient", "BOTH together are sufficient", "NEITHER is sufficient"],
    correctIndex: 0,
    explanation: "From (1): (even + odd = odd). If x + 3 is odd, x MUST be even. Statement 1 alone is SUFFICIENT.\nFrom (2): 2x is always even for any integer x (even or odd). Statement 2 alone is INSUFFICIENT.",
    formula: "Parity Rules: Even + Odd = Odd"
  },
  {
    id: "di_5",
    category: "Data Interpretation",
    subCategory: "Table Data",
    difficulty: "Medium",
    question: "A store sold 50 units of Product A at $10 each and 30 units of Product B at $20 each. What is the weighted average price per unit sold?",
    options: ["$13.75", "$14.00", "$15.00", "$16.25"],
    correctIndex: 0,
    explanation: "Total Revenue = (50 × 10) + (30 × 20) = 500 + 600 = $1100.\nTotal Units = 50 + 30 = 80 units.\nWeighted Average Price = 1100 / 80 = $13.75.",
    formula: "Weighted Avg = (w1*v1 + w2*v2) / (w1 + w2)"
  },
  {
    id: "di_6",
    category: "Data Interpretation",
    subCategory: "Pie Charts",
    difficulty: "Medium",
    question: "In a expenditure pie chart, Food accounts for 30%, Rent accounts for 25%, and Savings accounts for 20%. If total income is $5,000, how much money is spent on Food and Rent combined?",
    options: ["$2,250", "$2,500", "$2,750", "$3,000"],
    correctIndex: 2,
    explanation: "Combined percentage for Food + Rent = 30% + 25% = 55%.\nTotal amount = 55% of $5,000 = 0.55 × 5000 = $2,750.",
    formula: "Combined Value = Total Income × Combined %"
  },
  {
    id: "di_7",
    category: "Data Interpretation",
    subCategory: "Bar Graphs",
    difficulty: "Hard",
    question: "Production output: Factory A produced 500 units in 2022 and 650 units in 2023. Factory B produced 400 units in 2022 and 600 units in 2023. Which factory showed a higher percentage growth?",
    options: ["Factory A", "Factory B", "Both had equal growth", "Cannot be determined"],
    correctIndex: 1,
    explanation: "Factory A growth % = (650 - 500)/500 = 150 / 500 = 30%.\nFactory B growth % = (600 - 400)/400 = 200 / 400 = 50%.\nFactory B grew by 50%, which is higher than Factory A (30%).",
    formula: "% Growth Comparison"
  },
  {
    id: "di_8",
    category: "Data Interpretation",
    subCategory: "Data Sufficiency",
    difficulty: "Medium",
    question: "Question: What is the value of x?\nStatement (1): 3x + 5 = 20\nStatement (2): x² = 25",
    options: ["Statement (1) ALONE is sufficient", "Statement (2) ALONE is sufficient", "Either statement alone is sufficient", "Both statements together are needed"],
    correctIndex: 0,
    explanation: "From (1): 3x = 15 => x = 5 (unique value). Sufficient!\nFrom (2): x = 5 or x = -5 (two values, ambiguous). Insufficient!\nTherefore, Statement (1) alone is sufficient.",
    formula: "Uniqueness test for linear vs quadratic equations"
  },

  // -------------------------------------------------------------
  // 5. COMPUTER & CODING CONCEPTS (10 Questions)
  // -------------------------------------------------------------
  {
    id: "cs_1",
    category: "Computer & Coding Concepts",
    subCategory: "Time Complexity",
    difficulty: "Medium",
    question: "What is the worst-case time complexity of the Quick Sort algorithm?",
    options: ["O(n log n)", "O(n)", "O(n²)", "O(2ⁿ)"],
    correctIndex: 2,
    explanation: "While Quick Sort averages O(n log n), its worst-case complexity degrades to O(n²) when the chosen pivot is consistently the smallest or largest element (e.g., an already sorted array with poor pivot selection).",
    formula: "Worst-case recurrences T(n) = T(n-1) + O(n) => O(n²)"
  },
  {
    id: "cs_2",
    category: "Computer & Coding Concepts",
    subCategory: "Data Structures",
    difficulty: "Easy",
    question: "Which data structure operates strictly on a Last-In, First-Out (LIFO) protocol?",
    options: ["Queue", "Stack", "Array", "Linked List"],
    correctIndex: 1,
    explanation: "A Stack manages elements using LIFO (Last-In, First-Out), where push and pop operations occur at the top of the stack.",
    formula: "Stack = LIFO; Queue = FIFO"
  },
  {
    id: "cs_3",
    category: "Computer & Coding Concepts",
    subCategory: "Output Prediction",
    difficulty: "Medium",
    question: "What will be the output of evaluating `[1, 2, 3] + [4, 5]` in Python?",
    options: ["[1, 2, 3, 4, 5]", "[5, 7, 3]", "TypeError", "[[1,2,3], [4,5]]"],
    correctIndex: 0,
    explanation: "In Python, using the `+` operator on two lists concatenates them into a single merged list: `[1, 2, 3, 4, 5]`.",
    formula: "Python list concatenation operator"
  },
  {
    id: "cs_4",
    category: "Computer & Coding Concepts",
    subCategory: "OOPs Concepts",
    difficulty: "Medium",
    question: "Which Object-Oriented Programming paradigm allows a subclass to replace a parent class's method implementation at runtime?",
    options: ["Overloading", "Overriding", "Encapsulation", "Abstraction"],
    correctIndex: 1,
    explanation: "Method Overriding allows a derived child class to provide a specific implementation of a method that is already declared in its parent class.",
    formula: "Dynamic Polymorphism via Method Overriding"
  },
  {
    id: "cs_5",
    category: "Computer & Coding Concepts",
    subCategory: "SQL Queries",
    difficulty: "Easy",
    question: "Which SQL clause is used to filter group records after an aggregate function like `COUNT()` or `SUM()` has been applied?",
    options: ["WHERE", "HAVING", "GROUP BY", "ORDER BY"],
    correctIndex: 1,
    explanation: "The `HAVING` clause filters aggregated group rows created by `GROUP BY`, whereas `WHERE` filters rows before aggregation.",
    formula: "SQL Evaluation Order: WHERE -> GROUP BY -> HAVING"
  },
  {
    id: "cs_6",
    category: "Computer & Coding Concepts",
    subCategory: "Data Structures",
    difficulty: "Hard",
    question: "What is the worst-case lookup time complexity in a balanced Binary Search Tree (AVL Tree or Red-Black Tree)?",
    options: ["O(1)", "O(log n)", "O(n)", "O(n log n)"],
    correctIndex: 1,
    explanation: "Self-balancing binary search trees maintain a maximum height of O(log n), guaranteeing search, insertion, and deletion in O(log n) worst-case time.",
    formula: "Tree height h = O(log n)"
  },
  {
    id: "cs_7",
    category: "Computer & Coding Concepts",
    subCategory: "Output Prediction",
    difficulty: "Hard",
    question: "In JavaScript, what is the output of `console.log(typeof NaN)`?",
    options: ["'number'", "'NaN'", "'undefined'", "'object'"],
    correctIndex: 0,
    explanation: "In JavaScript, `NaN` stands for 'Not-a-Number', but its technical data type according to the ECMAScript spec is `'number'`. ",
    formula: "JS Type Spec: typeof NaN === 'number'"
  },
  {
    id: "cs_8",
    category: "Computer & Coding Concepts",
    subCategory: "Algorithms",
    difficulty: "Medium",
    question: "Which algorithmic strategy is used by Binary Search?",
    options: ["Greedy Approach", "Dynamic Programming", "Divide and Conquer", "Backtracking"],
    correctIndex: 2,
    explanation: "Binary Search continuously divides a sorted search space in half, eliminating one half at each step—a classic Divide and Conquer technique.",
    formula: "Divide and Conquer paradigm"
  },
  {
    id: "cs_9",
    category: "Computer & Coding Concepts",
    subCategory: "SQL Queries",
    difficulty: "Medium",
    question: "What type of SQL JOIN returns all rows from the left table and matched rows from the right table, filling with NULLs for unmatched right rows?",
    options: ["INNER JOIN", "LEFT JOIN", "RIGHT JOIN", "FULL OUTER JOIN"],
    correctIndex: 1,
    explanation: "A `LEFT JOIN` (or `LEFT OUTER JOIN`) preserves all records from the left table regardless of whether there is a match in the right table.",
    formula: "Relational Algebra: Left Outer Join"
  },
  {
    id: "cs_10",
    category: "Computer & Coding Concepts",
    subCategory: "OOPs Concepts",
    difficulty: "Easy",
    question: "Wrapping data attributes and methods into a single protective unit while restricting direct external access is called:",
    options: ["Inheritance", "Polymorphism", "Encapsulation", "Compilation"],
    correctIndex: 2,
    explanation: "Encapsulation bundles state variables and behavior within a class and restricts direct access to internal details using access modifiers.",
    formula: "Encapsulation = Data Hiding + Bundling"
  },

  // -------------------------------------------------------------
  // 6. SPATIAL & ABSTRACT REASONING (6 Questions)
  // -------------------------------------------------------------
  {
    id: "spat_1",
    category: "Spatial & Abstract Reasoning",
    subCategory: "Mirror Images",
    difficulty: "Easy",
    question: "If a standard analog clock showing 3:00 is viewed in a plane vertical mirror, what time will the mirror image depict?",
    options: ["3:00", "6:00", "9:00", "12:00"],
    correctIndex: 2,
    explanation: "In a vertical mirror reflection, horizontal directions reverse. The hour hand pointing right (at 3) flips left (pointing at 9). The minute hand at 12 remains straight up. The reflected time is 9:00.",
    formula: "Reflected Time = 12:00 - Original Time"
  },
  {
    id: "spat_2",
    category: "Spatial & Abstract Reasoning",
    subCategory: "Pattern Completion",
    difficulty: "Medium",
    question: "A square matrix contains shapes that rotate clockwise by 45 degrees at each step. If step 1 points North and step 2 points North-East, what direction will step 5 point?",
    options: ["East", "South-East", "South", "South-West"],
    correctIndex: 2,
    explanation: "Rotation: Step 1 (0° North) -> Step 2 (45° NE) -> Step 3 (90° East) -> Step 4 (135° SE) -> Step 5 (180° South).",
    formula: "Angle = (Step - 1) × 45°"
  },
  {
    id: "spat_3",
    category: "Spatial & Abstract Reasoning",
    subCategory: "Matrix Reasoning",
    difficulty: "Hard",
    question: "In a 3x3 matrix pattern, Row 1 has 3 dots, Row 2 has 6 dots, and Row 3 follows the rule (Row 1 + Row 2). How many dots belong in Row 3?",
    options: ["7 dots", "8 dots", "9 dots", "12 dots"],
    correctIndex: 2,
    explanation: "Following the defined additive matrix rule: Row 3 = Row 1 (3 dots) + Row 2 (6 dots) = 9 dots.",
    formula: "Row 3 = Row 1 + Row 2"
  },
  {
    id: "spat_4",
    category: "Spatial & Abstract Reasoning",
    subCategory: "Pattern Completion",
    difficulty: "Easy",
    question: "How many triangles are present in a square divided by both of its main diagonal lines?",
    options: ["4", "6", "8", "10"],
    correctIndex: 2,
    explanation: "Inside a square with intersecting diagonals: 4 small single-piece triangles + 4 larger composite triangles formed by adjacent pairs = 8 total triangles.",
    formula: "Triangles in square with 2 diagonals = 4 × 2 = 8"
  },
  {
    id: "spat_5",
    category: "Spatial & Abstract Reasoning",
    subCategory: "Mirror Images",
    difficulty: "Medium",
    question: "Choose the correct mirror reflection for the string 'AMBULANCE' when reflected horizontally:",
    options: ["AMBULANCE", "ƎƆNA⅃UBMA", "ECNALUBMA", "∀W𐐒∩˥∀NƆƎ"],
    correctIndex: 1,
    explanation: "Horizontal mirror reflection reverses letter order from right to left while laterally inverting individual asymmetrical glyphs -> ƎƆNA⅃UBMA.",
    formula: "Lateral inversion rule"
  },
  {
    id: "spat_6",
    category: "Spatial & Abstract Reasoning",
    subCategory: "Matrix Reasoning",
    difficulty: "Hard",
    question: "A cube of side 3 cm is painted red on all outer surfaces and then cut into smaller 1 cm cubes. How many small cubes have EXACTLY 2 faces painted red?",
    options: ["8", "12", "18", "24"],
    correctIndex: 1,
    explanation: "For a cube of side n = 3:\nCubes with 2 faces painted lie on the edges (excluding corners).\nFormula = 12 × (n - 2) = 12 × (3 - 2) = 12 small cubes.",
    formula: "2-Face Painted Cubes = 12 × (n - 2)"
  }
];
