export interface Question {
  id: string;
  category: string;
  subCategory: string;
  difficulty: 'Easy' | 'Medium' | 'Hard' | string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  formula?: string;
}

export interface QuizSession {
  id: number;
  date: string;
  questions: Question[];
  userAnswers: (number | null)[];
  timeLimit: number;
  timeElapsed: number;
  mode: 'test' | 'practice' | string;
  isFinished: boolean;
}

export interface CompletedResult extends QuizSession {
  score: number;
  total: number;
  percentage: number;
  categoryStats: Record<string, { total: number; correct: number }>;
  finishedAt: string;
}
